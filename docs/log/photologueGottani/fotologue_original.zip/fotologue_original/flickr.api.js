/*
	flickr.api.js
*/

var flickr =

(function(){

	function FlickrAPI( _param, _callback )
	{
		this.data;
		this.param;
		this.callback;
		this._initialize.apply( this, arguments )
	}

	FlickrAPI.obj2query = function( obj )
	{
		var list = [];
		for( var key in obj ) {
			var k = encodeURIComponent(key);
			var v = encodeURIComponent(obj[key]);
			list[list.length] = k+'='+v;
		}
		var query = list.join( '&' );
		return query;
	}

	FlickrAPI.prototype = {
		load	: function(){
			this._photoSearch();
		}, 
		_initialize: function( _param, _callback )
		{
			this.data = new Array();
			this.param = _param;
			this.callback = _callback;
		},
		_photoSearch	: function()
		{
			//	ajaxでflickrAPIにアクセス
			var _this = this;
			$.ajax({
				type		: 'GET',
				url			: 'http://www.flickr.com/services/rest/?'+FlickrAPI.obj2query( this.param ),
				/*data				: {
					format  : 'json',
					user_id : user_id,
					api_key : flickr_api_key,
					method  : 'flickr.photos.search'
				},*/
				dataType	: 'jsonp',
				jsonp   	: 'jsoncallback',
				success		: function( json )
				{
					_this.callback( _this._jsonFlickrApi( json ) );
				}
		    });
		},
		_jsonFlickrApi	: function( data )
		{
			// データが取得できているかチェック
			if ( ! data ) return;
			if ( ! data.photos ) return;
			var list = data.photos.photo;
			if ( ! list ) return;
			if ( ! list.length ) return;

			//	データリストを作る
			var _l = new Array();
			for( var i=0; i<list.length; i++ ) {
				var photo = list[i];
				_l.push( new imageData( photo ) );
			}
			return _l
		}
	};

	return FlickrAPI;
})();


/*
	var param = {};
	param.api_key  = 'd4eb16f01f273977fbe3972962e1646e';
	param.user_id = '35921197@N04';
	param.method   = 'flickr.photos.search';
	param.per_page = 100;
	param.sort	= 'date-posted-desc';
	param.format   = 'json';
	param.extras   = 'date_taken,tags';
	param.tags = 'square';
	param.jsoncallback = 'jsonFlickrApi';
	photoSearch( param );
*/
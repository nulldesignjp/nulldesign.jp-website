/*
	main.js
*/

window.onload = function()
{

	/*	-------------------------------------------------------------
		UA情報の取得
	-------------------------------------------------------------	*/
	var ua = getUA();
	
	/*	-------------------------------------------------------------
		IE系特殊対応
	-------------------------------------------------------------	*/
	if( ua.msie6 || ua.maie7 || ua.msie8 )
	{

	}
	
	/*	-------------------------------------------------------------
		android対応
	-------------------------------------------------------------	*/
	if( ua.android )
	{

	}
	
	/*	-------------------------------------------------------------
		androidTablet対応
	-------------------------------------------------------------	*/
	if( ua.androidTablet )
	{

	}

	/*	-------------------------------------------------------------
		main
	-------------------------------------------------------------	*/

	//photo_search({});

	//	非対応ブラウザ処理
	if( ua.ie6 || ua.ie7 )
	{
		_noContents();
		return;
	}

	//	imageData list
	var _dataList = new Array();

	//	fade in
	setTimeout(function(){
		$('body').css('display','block');
	}, 1000 );

	var _siteHead = $( '#siteHead' );
	var _title = $( '#siteHead hgroup h1' );
	var _description = $( '#siteHead hgroup h2' );
	var _name = $( 'aside.description p' ).eq(0);
	var _url = $( 'aside.description p' ).eq(1);
	var _copy = $( 'aside.description p' ).eq(2);
	var _sns = $( 'aside.snsBlock' );

	$( [_title,_description,_name,_url,_copy,_sns] ).each(function(i,e){
		//console.log( e );
		$( this ).css('opacity', 0).delay( i*250 + 1500 ).animate({'opacity':1}, 1000 );
	});

	//	load flickr API.
	var param = {};
	param.api_key  = 'd4eb16f01f273977fbe3972962e1646e';
	param.user_id = '35921197@N04';
	param.method   = 'flickr.photos.search';
	param.per_page = 100;
	param.sort		= 'date-posted-desc';
    param.format   = 'json';
    param.extras   = 'date_taken,tags';
    param.tags = 'square';
    //param.jsoncallback = 'jsonFlickrApi';
	//photoSearch( param );

	var _fl = new flickr( param, _callback );
	_fl.load();

	var _f0 = document.createElement( 'div' );
	_f0.className = 'film';
	var _wrap0 = document.createElement( 'div' );
	_f0.appendChild( _wrap0 );
	$( '#documentBody').append( _f0 );
	var _f1 = document.createElement( 'div' );
	_f1.className = 'film';
	var _wrap1 = document.createElement( 'div' );
	_f1.appendChild( _wrap1 );
	$( '#documentBody').append( _f1 );
	var _f2 = document.createElement( 'div' );
	_f2.className = 'film';
	var _wrap2 = document.createElement( 'div' );
	_f2.appendChild( _wrap2 );
	$( '#documentBody').append( _f2 );
	var _f3 = document.createElement( 'div' );
	_f3.className = 'film';
	var _wrap3 = document.createElement( 'div' );
	_f3.appendChild( _wrap3 );
	$( '#documentBody').append( _f3 );

	function _callback( _arr )
	{
		_dataList = _arr;
		var _l = _dataList;
		var len = _l.length;
		var _b = [_wrap0,_wrap1,_wrap2];
		for( var i = 0; i < len; i++ )
		{
			var _img = new Image();
			_img.src = _l[i].small;
			$( _img ).css({'opacity': 0, 'cursor': 'pointer'}).attr( 'limg', _l[i].middle );

			_img.onload = function(e){
				$( _b[Math.floor(Math.random() * _b.length)] ).append( e.target );
				$( e.target ).delay( 500 ).animate({'opacity': .5}, 1000 );

				$( e.target ).mousedown( function(w){
					createCard( $(this).attr('limg') );
				})
			}
		}
		for( var i = 0; i < len; i++ )
		{
			var _img = new Image();
			_img.src = _l[i].thumbnail;
			$( _img ).css({'opacity': 0, 'cursor': 'pointer'}).attr( 'limg', _l[i].middle );
			
			_img.onload = function(e){
				$( _wrap3 ).append( e.target );
				$(e.target).delay( 500 ).animate({'opacity': .4}, 1000 );

				$( e.target ).mousedown( function(w){
					createCard( $(this).attr('limg') );
				})
			}
		}

		//$( 'body' ).css( '-webkit-transform','perspective(1000)' );

		//setTimeout( _scrollImages, 3000 );

	}

	function createCard( _img )
	{
		var _c = new card( _img );
		$( '#documentBody' ).append( _c.view );
	}

	function _scrollImages()
	{
		var _w = $('div.film img').eq(0).width();
		$('div.film div').each(function(i,e){
			$( this ).css({
				'transition-timing-function': 'ease',
				'-moz-transition-timing-function': 'ease',
				'-webkit-transition-timing-function': 'ease',
				'-o-transition-timing-function': 'ease',
				'-ms-transition-timing-function': 'ease',
				'transition-duration'	:	'0.8s',
				'-moz-transition-duration'	:	'0.8s',
				'-webkit-transition-duration' : '0.8s',
				'-o-transition-duration'	:	'0.8s',
				'-ms-transition-duration'	:	'0.8s',
				'marginLeft': - _w + 'px'
			});
			var _this = this;
			setTimeout( function(){
				$( _this ).css({'marginLeft': 0});
				$( _this ).append( $( _this ).find('img')[0] );
				_scrollImages();
			}, 1000 )
		});
	}


	$(window).bind( 'resize', __resize );
	function __resize( e ){	_resize();	}
	function _resize()
	{
		var _w = $(window).width();
		var _h = $(window).height();
		var _length = ( _w > _h )? _w:_h;
		_length *= 2;

		var _x0 = -200;
		var _y0 = _h * .7;
		var _x1 = _w * .8;
		var _y1 = -200;
		var _deg = Math.floor( Math.atan2( _y1 - _y0, _x1 - _x0 ) / Math.PI * 180 );

		$( _f0 ).css({
			//'-webkit-transform':'translate3d(0,0,0)',
			'transform-origin': 'left top',
			'-webkit-transform-origin': 'left top',
			'-moz-transform-origin': 'left top',
			'-o-transform-origin': 'left top',
			'-ms-transform-origin': 'left top',
			'transform': 'rotate('+_deg+'deg)',
			'-webkit-transform': 'rotate('+_deg+'deg)',
			'-moz-transform': 'rotate('+_deg+'deg)',
			'-o-transform': 'rotate('+_deg+'deg)',
			'-ms-transform': 'rotate('+_deg+'deg)',
			'width': _length + 'px',
			'top': _y0 + 'px',
			'left': _x0 + 'px'
		});



		_x0 = -200;
		_y0 = _h * .4;
		_x1 = _w + 200;
		_y1 = _h;
		_deg = Math.floor( Math.atan2( _y1 - _y0, _x1 - _x0 ) / Math.PI * 180 ) + 0;

		$( _f1 ).css({
			//'-webkit-transform':'translate3d(0,0,0)',
			'transform-origin': 'left top',
			'-webkit-transform-origin': 'left top',
			'-moz-transform-origin': 'left top',
			'-o-transform-origin': 'left top',
			'-ms-transform-origin': 'left top',
			'transform': 'rotate('+_deg+'deg)',
			'-webkit-transform': 'rotate('+_deg+'deg)',
			'-moz-transform': 'rotate('+_deg+'deg)',
			'-o-transform': 'rotate('+_deg+'deg)',
			'-ms-transform': 'rotate('+_deg+'deg)',
			'width': _length + 'px',
			'top': _y0 + 'px',
			'left': _x0 + 'px'
		});

		_x0 = _w * .35;
		_y0 = -200;
		_x1 = _w *.8;
		_y1 = _h + 200;
		_deg = Math.floor( Math.atan2( _y1 - _y0, _x1 - _x0 ) / Math.PI * 180 ) + 0;

		$( _f2 ).css({
			//'-webkit-transform':'translate3d(0,0,0)',
			'transform-origin': 'left top',
			'-webkit-transform-origin': 'left top',
			'-moz-transform-origin': 'left top',
			'-o-transform-origin': 'left top',
			'-ms-transform-origin': 'left top',

			'transform': 'rotate('+_deg+'deg)',
			'-webkit-transform': 'rotate('+_deg+'deg)',
			'-moz-transform': 'rotate('+_deg+'deg)',
			'-o-transform': 'rotate('+_deg+'deg)',
			'-ms-transform': 'rotate('+_deg+'deg)',

			'width': _length + 'px',
			'top': _y0 + 'px',
			'left': _x0 + 'px'
		});

		_x0 = _w * .2;
		_y0 = _h + 400;
		_x1 = _w;
		_y1 = - 400;
		_deg = Math.floor( Math.atan2( _y1 - _y0, _x1 - _x0 ) / Math.PI * 180 ) + 0;

		$( _f3 ).css({
			//'-webkit-transform':'translate3d(0,0,0)',
			'transform-origin': 'left top',
			'-webkit-transform-origin': 'left top',
			'-moz-transform-origin': 'left top',
			'-o-transform-origin': 'left top',
			'-ms-transform-origin': 'left top',

			'transform': 'rotate('+_deg+'deg)',
			'-webkit-transform': 'rotate('+_deg+'deg)',
			'-moz-transform': 'rotate('+_deg+'deg)',
			'-o-transform': 'rotate('+_deg+'deg)',
			'-ms-transform': 'rotate('+_deg+'deg)',

			'width': _length * 3 + 'px',
			'top': _y0 + 'px',
			'left': _x0 + 'px'
		});
	}

	_resize();
	


	/*	-------------------------------------------------------------
		scroll and resize
	-------------------------------------------------------------	*/
	/*
	addEventListeners( 'scroll', _scroll );
	addEventListeners( 'resize', _resize );
	addEventListeners( 'orientationchange', _orientation )
	function _scroll(e){}
	function _resize(e){}

	if( ua.iphone || ua.ipod || ua.ipad || ua.android )
	{
		function _orientation(e){
			_reZoom();
		}
		function _reZoom()
		{
			var _scale = $(window).width() / 960;
			$('body').css({
				'zoom': _scale
			});
		}
		_reZoom();
	}
	*/







	/*
		以下処理系の関数等
	*/
	/*	-------------------------------------------------------------
		user agene
	-------------------------------------------------------------	*/
	function getUA()
	{
		var ua =
		{
			'msie'	:	false,
			'msie6'	:	false,
			'msie7'	:	false,
			'msie8'	:	false,
			'msie9'	:	false,
			'msie10'	:	false,
			'iphone'	:	false,
			'ipad'	:	false,
			'ipod'	:	false,
			'safari'	:	false,
			'firefox'	:	false,
			'chrome'	:	false,
			'opera'	:	false,
			'android'	:	false,
			'androidTablet'	:	false,
			'blackberry'	:	false,
			'windowsMobile'	:	false
		};
		var _ua = navigator.userAgent.toLowerCase();
		_ua = _ua.replace(/ /g, "");
		for( var i in ua )
		{
			if( _ua.indexOf( i ) != -1 )
			{
				ua[i] = true;
			}
		}

		//	例外処理
		if( ua.android )
		{
			//	通常のアンドロイド端末
			ua.android = ( ( _ua.indexOf( 'android' ) != -1 && _ua.indexOf( 'mobile' ) != -1 ) && _ua.indexOf( 'sc-01c' ) == -1 )?	true:false;

			//	アンドロイドタブレット端末	※ SC-01C は限定機種対応......	
			ua.androidTablet = ( _ua.indexOf( 'android' ) != -1 && ( _ua.indexOf( 'mobile' ) == -1 || _ua.indexOf( 'sc-01c' ) != -1 ) )?	true:false;

			alert
		}

		//	windows mobile
		ua.windowsMobile = ( _ua.indexOf( 'IEMobile' ) != -1 )?	true:false;
		return ua;
	}

	/*	-------------------------------------------------------------
		addEventListener ie and other.
	-------------------------------------------------------------	*/
	function addEventListeners( _event, _callback )
	{
		if( ua.msie )
		{
			document.attachEvent( 'on' + _event, _callback );
		} else {
			window.addEventListener( _event, _callback, false );
		}
	}

	/*	-------------------------------------------------------------
		utils
	-------------------------------------------------------------	*/

	function createElement( _elm, _string )
	{
		var _element = document.createElement( _elm );
		if( _string )
		{
			var _txtNode = document.createTextNode( _string );
			_element.appendChild( _txtNode );
		}
		return _element;
	}

	function _noContents()
	{
		var _div = document.createElement('div');
		_div.id = 'noContents';

		var _txt = document.createElement('p');
		var _string = document.createTextNode('お使いのブラウザは、本サイト比対応のブラウザです。');
		_txt.appendChild( _string );
		_div.appendChild( _txt );

		document.body.appendChild( _div );
	}

	//	http://itpro.nikkeibp.co.jp/article/COLUMN/20061101/252356/

	// 画像検索を行う関数
	function photoSearch ( param ) {
	    var url = 'http://www.flickr.com/services/rest/?'+obj2query( param );

	    // script 要素の発行
	    var script  = document.createElement( 'script' );
	    script.type = 'text/javascript';
	    script.src  = url;
	    document.body.appendChild( script );
	};

	// オブジェクトからクエリー文字列を生成する関数
	function obj2query ( obj )
	{
	    var list = [];
	    for( var key in obj ) {
			var k = encodeURIComponent(key);
			var v = encodeURIComponent(obj[key]);
			list[list.length] = k+'='+v;
	    }
	    var query = list.join( '&' );
	    return query;
	}

	// Flickr検索終了後のコールバック関数
	function jsonFlickrApi ( data )
	{
	    // データが取得できているかチェック
	    if ( ! data ) return;
	    if ( ! data.photos ) return;
	    var list = data.photos.photo;
	    if ( ! list ) return;
	    if ( ! list.length ) return;

	    //	データリストを作る
	    var _l = new Array()
	    for( var i=0; i<list.length; i++ ) {
			var photo = list[i];
			_l.push( new imageData( photo ) );
	    }
	    return _l;
	}
}
